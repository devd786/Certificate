package com.telstra.ccom.Multithreading.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.telstra.ccom.Multithreading.Service.FulfilmentOrderItemService;

@RestController
public class FulfilmentOrderItemController {
    @Autowired
    private FulfilmentOrderItemService fulfilmentOrderItemService;

    @PostMapping("/updateFulfilmentStatus")
    public ResponseEntity<String> updateStatus(@RequestParam Long itemId) {
        fulfilmentOrderItemService.runConcurrentStatusUpdate(itemId);
        return ResponseEntity.ok("Concurrent fulfilment status update started with 50 threads for item ID: " + itemId);
    }
}
