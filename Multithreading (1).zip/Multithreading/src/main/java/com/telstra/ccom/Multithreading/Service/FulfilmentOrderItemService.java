package com.telstra.ccom.Multithreading.Service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.telstra.ccom.Multithreading.Entity.FulfilmentOrderItem;
import com.telstra.ccom.Multithreading.Repository.FulfilmentOrderItemRepository;

//FulfilmentService.java
@Service
public class FulfilmentOrderItemService {
    @Autowired
    private FulfilmentOrderItemRepository fulfilmentOrderItemRepository;

    @Autowired
    private ThreadPoolTaskExecutor taskExecutor;

    public void runConcurrentStatusUpdate(Long itemId) {
        int numberOfThreads = 100;
        CountDownLatch latch = new CountDownLatch(numberOfThreads);

        for (int i = 0; i < numberOfThreads; i++) {
            taskExecutor.execute(() -> {
                updateFulfilmentStatus(itemId, "IComplete", latch);
            });
        }

        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void updateFulfilmentStatus(Long id, String status, CountDownLatch latch) {
        FulfilmentOrderItem item = fulfilmentOrderItemRepository.findById(id).orElse(null);
        if (item != null) {
            item.setFulfilmentStatus(status);
            fulfilmentOrderItemRepository.save(item);
        }
        latch.countDown();
    }
}
