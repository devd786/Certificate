package com.telstra.ccom.Multithreading;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultithreadingApplicationTests {

	@Test
	void contextLoads() {
	}

}
